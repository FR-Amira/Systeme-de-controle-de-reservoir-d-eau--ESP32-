from machine import Pin
import time
ledRED = Pin(25,Pin.OUT) 
ledBlue = Pin(33,Pin.OUT)
while True:
    ledBlue.value(1)
    time.sleep(1) 
    ledBlue.value(0)
    time.sleep(1)
    ledRED.on()
    time.sleep(1) 
    ledRED.off()
    time.sleep_ms(1000)



