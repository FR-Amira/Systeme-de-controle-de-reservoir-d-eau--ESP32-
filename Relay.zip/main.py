from machine import Pin
import time
Relay = Pin(26,Pin.OUT)


for i in range(5):
    Relay.on()
    time.sleep(0.5)
    Relay.off()
    time.sleep(10.5)