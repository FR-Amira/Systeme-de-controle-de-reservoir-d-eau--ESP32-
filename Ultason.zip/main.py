from machine import Pin 
import time

Trig = Pin(32,Pin.OUT)
Echo = Pin(33,Pin.IN)
Toff = Ton = T = distance = 0
while 1 :
    Trig.on()
    time.sleep_us(10)
    Trig.off()
    time.sleep_us(2)
    while Echo.value() == 0 :
        Toff = time.ticks_us()
    while Echo.value() == 1 :
        Ton = time.ticks_us()
    T = Ton - Toff
    distance = ( T * 0.0343 ) / 2
    print(distance)
    time.sleep_ms(20)