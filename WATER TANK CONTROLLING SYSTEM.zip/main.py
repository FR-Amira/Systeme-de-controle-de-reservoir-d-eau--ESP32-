from machine import Pin 
import time
RelayIN = Pin(26,Pin.OUT)
RelayOUT = Pin(2,Pin.OUT)
Trig = Pin(32,Pin.OUT)
Echo = Pin(33,Pin.IN)
Toff = Ton = T = distance = water = 0
while 1 :
    Trig.on()
    time.sleep_us(10)
    Trig.off()
    time.sleep_us(2)
    while Echo.value() == 0 :
        Toff = time.ticks_us()
    while Echo.value() == 1 :
        Ton = time.ticks_us()
    T = Ton - Toff
    distance = ( T * 0.034 ) / 2
    water = 400 - distance 
    time.sleep_ms(20)
    if  100 < water < 300 :
        print("Niveau moyenne","    water =" , water,"cm",)
        RelayIN.on()
        RelayOUT.on()
    elif water > 300  :
        print("Niveau Haut","   water =" , water,"cm",)
        RelayIN.off()
        RelayOUT.on()
    else :
        print("Niveau Bas","    water =" , water,"cm",)
        RelayIN.on()
        RelayOUT.off()







